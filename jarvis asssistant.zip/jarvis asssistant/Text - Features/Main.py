import pyaudio
from types import coroutine
import pyttsx3
import speech_recognition as sr
from Features import GoogleSearch
from win10toast import ToastNotifier
import datetime
import time
from Automations import ChromeAuto
from Automations import YouTubeAuto
from Automations import WindiowsAuto
from pyautogui import click
from keyboard import press
from keyboard import press_and_release
from keyboard import write
from time import sleep
import webbrowser as web
from Automations import *




engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voices',voices[1].id)



def speak(audio):
    print(" ")
    print(f": {audio}")
    engine.say(audio)
    engine.runAndWait()
    print(" ")

def TakeCommand():

    r = sr.Recognizer()

    with sr.Microphone() as source:

        print(": Listening....")

        r.pause_threshold = 1

        audio = r.listen(source)


    try:

        print(": Recognizing...")

        query = r.recognize_google(audio,language='en-in')

        print(f": Your Command : {query}\n")

    except:
        return ""

    return query.lower()

def TaskExe():
    
    speak('hello sir i am your desktop assistant \n how can i help you')

    while True:

        query = TakeCommand()

        
        
        if 'google search' in query:
            GoogleSearch(query)
        
        elif 'hai' in query :
            speak('hi sir how are you \n how can i help you ')

        elif 'how can you impress me' in query :
            speak('i think that ')
            sleep(2) 
            speak('i can impress you by my features \n you may try me')


        elif 'mum' in query :
            speak('santhi')
        
        elif 'dad' in query :
            speak('chenchaiah')

        elif 'your brother' in query :
            speak('manwith \n dheeraj \n rakesh')

        elif 'best friends' in query :
            speak('vijay \n ram \n teja')

        elif 'how are you' in query :
            speak('i am fine sir. how are you')

              
        
        elif 'day' in query :
            from Features import tellDay
            tellDay()
        
        elif 'youtube search' in query:
            Query = query.replace("jarvis","")
            query = Query.replace("youtube search","")
            from Features import YouTubeSearch
            YouTubeSearch(query)

        elif 'set alarm' in query:
            from Features import Alarm
            Alarm(query)

        elif 'download' in query:
            from Features import DownloadYouTube
            DownloadYouTube()
            
        elif 'speed test' in query:
            from Features import SpeedTest
            SpeedTest()


        elif 'temperature in' in query :
            
            from Features import Temp
            
            Temp(query)
        
        elif 'whatsapp message' in query:

            name = query.replace("whatsapp message","")
            name = name.replace("send ","")
            name = name.replace("to ","")
            Name = str(name)
            speak(f"Whats The Message For {Name}")
            MSG = TakeCommand()
            from Automations import WhatsappMsg
            WhatsappMsg(Name,MSG)
        
        elif 'call' in query:
            
            from Automations import WhatsappCall
            
            name = query.replace("call ","")
            
            name = name.replace("jarvis ","")
            
            Name = str(name)
            
            WhatsappCall(Name)  
            
        elif 'video call' in query:
            
            name = query.replace("video call to ","")
            Name = str(name)
            from Automations import WhatsappVideoCall
            WhatsappVideoCall(Name)    
           
        elif 'contact information' in query:
            
            name = query.replace("hey jarvis ","")
            name = name.replace("i need the contact information of ","")
            Name = str(name)
            from Automations import WhatsappContactinfo
            WhatsappContactinfo(Name)    
            
            
        elif 'new tab' in query :
            
            press_and_release('ctrl + t')
        
        elif 'close tab' in query :
            
            press_and_release('ctrl + w')
            
        elif 'new window' in query :
            
            press_and_release('ctrl + n')
            
        
        elif 'downloads' in query :
            
            press_and_release('ctrl + j')
        
        elif 'add bookmark' in query :
            
            press_and_release('ctrl + d')
            
            press('enter')
            
        elif 'incognito tab' in query :
            
            press_and_release('ctrl + shift + n')
            
        elif 'home page' in query :
            
            press_and_release('Alt + home')
            
        elif 'back page' in query:    
            press_and_release('Alt + Left Arrow')
            
        elif 'forward a page' in query:
            press_and_release('Alt + Right Arrow')
            
        elif 'full screen' in query :
            press_and_release('F11')
            
            
        elif 'zoom the page' in query :
            press_and_release('Ctrl + plus')
            
        elif 'zoom out the page' in query :
            press_and_release('Ctrl + -')
            
        elif 'switch tab' in query :
            tab = query.replace("switch tab ","")
            Tab = tab.replace("to","")
            num = Tab
            bb = f'ctrl + {num}'
            press_and_release(bb)
        
        elif 'open' in query:
            name = query.replace("open ","")
            NameA = str(name)
            string = "https://www." + NameA + ".com"

            string_2 = string.replace(" ","")

            web.open(string_2)
        
        elif 'page up' in query :
            press_and_release('Shift + Spacebar')
            
        elif 'go to top of the page' in query :
            press_and_release('Home')  
            
        elif 'go to bottom of the page' in query :
            press_and_release('End') 
            
        elif 'previous text' in query :
            press_and_release('Alt + Down Arrow')      
            
        elif 'next tab' in query :
            press_and_release('Ctrl+Tab')
            
        elif 'previous tab' in query :
            press_and_release('Ctrl+Shift+Tab')
            
        elif 'restore last tab' in query :
            press_and_release('Ctrl + Shift + T')
            
        elif 'close current window' in query :
            press_and_release('Ctrl + Shift + W')
            
        elif 'source code' in query :
            press_and_release('Ctrl+U')
            
        elif 'save the page' in query :
            press_and_release('Ctrl+S')
            
        elif 'refresh the page' in query :
            press_and_release('Ctrl+R')
            
        elif 'minimize window' in query :
            press_and_release('Windows + Down Arrow')
        
        elif 'quit google' in query :
            press_and_release('alt + f + x')
            
        elif 'maximize window' in query :
            press_and_release('Windows + Windows+Up Arrow')
            
        elif 'chrome menu' in query :
            press_and_release('Alt + e')
            
        elif 'show bookmark' in query :
            press_and_release('Ctrl + Shift + b')
            
        elif 'open bookmark manager' in query :
            press_and_release('Ctrl + Shift + o')
            
        elif 'history' in query :
            press_and_release('Ctrl + h')
            
        elif 'chrome task manager' in query :
            press_and_release('Shift + Esc')
            
        elif 'first item in the Chrome toolbar' in query :
            press_and_release('Shift + Alt + t')
            
        elif 'right most item in the Chrome toolbar' in query :
            press('F10')
            
        elif 'open developer tools' in query :
            press('F12')
            
            
        elif 'help centre' in query :
            press('F1')
            
        elif 'open feedback form' in query :
            press_and_release('Alt + Shift + i')
        
        elif 'open caret browsing' in query :
            press('F7')
            
        elif 'pause' in query:
                sleep(2)
                press('space bar')
            
        elif 'resume' in query:
            sleep(2)
            press('space bar')
            
        elif 'full screen' in query:
            sleep(2)
            press('f')
            
        elif 'film screen' in query:
            sleep(2)
            press('t')
            
        elif 'skip' in query:
            sleep(2)
            press('l')
        
        elif 'back' in query:
            sleep(2)
            press('j')
            
        elif 'increase' in query:
            sleep(2)
            press_and_release('Up')
            
        elif 'decrease' in query:
            sleep(2)
            press_and_release('Down')
            
        elif 'previous' in query:
            sleep(2)
            press_and_release('SHIFT + p')
            
        elif 'next' in query:
            sleep(2)
            press_and_release('SHIFT + n')
            
        elif 'search' in query:
            sleep(2)
            click(x=720, y=164)
            

            speak("What To Search Sir ?")

            search = TakeCommand()

            write(search)
            
            sleep(0.8)

            press('enter')

        elif 'mute' in query:
            sleep(2)
            press('m')
            
        elif 'unmute' in query:
            sleep(2)
            press('m')
            
        elif 'my channel' in query:
            sleep(2)
            web.open("https://www.youtube.com/channel/UCWe6qs-LWENISXVMajlDJvQ")
        
        elif 'home screen' in query:
            press_and_release('windows + m')
            
        elif 'minimize' in query:
            press_and_release('windows + m')

        elif 'show start' in query :
            press('windows')
        
        elif 'open setting' in query:
            press_and_release('windows + i')
            
        elif 'open search' in query:
            press_and_release('windows + s')
        
        elif 'screen shot' in query:
            press_and_release('windows + SHIFT + s')
            
        elif 'restore windows' in  query:
            press_and_release('Windows + Shift + M')
            
        
         


TaskExe()
