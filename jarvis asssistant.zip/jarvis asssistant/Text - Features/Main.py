import pyaudio
from types import coroutine
import pyttsx3
import speech_recognition as sr
from Features import GoogleSearch
from win10toast import ToastNotifier
import datetime
import time
from Automations import ChromeAuto
from Automations import YouTubeAuto
from Automations import WindiowsAuto
from pyautogui import click
from keyboard import press
from keyboard import press_and_release
from keyboard import write
from time import sleep


engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voices',voices[1].id)

def speak(audio):
    print(" ")
    print(f": {audio}")
    engine.say(audio)
    engine.runAndWait()
    print(" ")

def TakeCommand():

    r = sr.Recognizer()

    with sr.Microphone() as source:

        print(": Listening....")

        r.pause_threshold = 1

        audio = r.listen(source)


    try:

        print(": Recognizing...")

        query = r.recognize_google(audio,language='en-in')

        print(f": Your Command : {query}\n")

    except:
        return ""

    return query.lower()

def TaskExe():

    while True:

        query = TakeCommand()

        if 'google search' in query:
            GoogleSearch(query)
        
        elif 'youtube search' in query:
            Query = query.replace("jarvis","")
            query = Query.replace("youtube search","")
            from Features import YouTubeSearch
            YouTubeSearch(query)

        elif 'set alarm' in query:
            from Features import Alarm
            Alarm(query)

        elif 'download' in query:
            from Features import DownloadYouTube
            DownloadYouTube()
            
        elif 'speed test' in query:
            from Features import SpeedTest
            SpeedTest()


        elif 'temperature in' in query :
            
            from Features import Temp
            
            Temp(query)
        
        elif 'whatsapp message' in query:

            name = query.replace("whatsapp message","")
            name = name.replace("send ","")
            name = name.replace("to ","")
            Name = str(name)
            speak(f"Whats The Message For {Name}")
            MSG = TakeCommand()
            from Automations import WhatsappMsg
            WhatsappMsg(Name,MSG)
        
        elif 'call' in query:
            
            from Automations import WhatsappCall
            
            name = query.replace("call ","")
            
            name = name.replace("jarvis ","")
            
            Name = str(name)
            
            WhatsappCall(Name)  
            
        elif 'video call' in query:
            
            name = query.replace("video call to ","")
            Name = str(name)
            from AutomationS import WhatsappVideoCall
            WhatsappVideoCall(Name)    
           
        elif 'contact information' in query:
            
            name = query.replace("hey jarvis ","")
            name = name.replace("i need the contact information of ","")
            Name = str(name)
            from Automations import WhatsappContactinfo
            WhatsappContactinfo(Name)    
            
        elif 'chrome' in query :
            
            from Automations import ChromeAuto
            
            ChromeAuto(query)
            
            elif 'new tab' in query :
                
                press_and_release('ctrl + w')
            
            elif 'close tab' in query :
                
                press_and_release('ctrl + n')
                
            elif 'new window' in query :
                
                press_and_release('ctrl + h')
                
            elif 'downloads' in query :
                
                press_and_release('ctrl + j')
            
            elif 'bookmark' in query :
                
                press_and_release('ctrl + d')
                
                press('enter')
                
            elif 'incognito tab' in query :
                
                press_and_enter('ctrl + shift + n')
                
            elif 'homepage' in query :
                
                press_and_enter('alt + home')
                
            elif 'back page' in query:    
                press_and_enter('Alt + Left Arrow')
                
            elif 'forward a page' in query:
                press_and_enter('Alt + Right Arrow')
                
            elif 'full screen' in query :
                press_and_enter('F11')
                
            elif 'stop download' in query :
                press_and_enter('esc')
                
            elif 'zoom the page' in query :
                press_and_enter('Ctrl + +')
                
            elif 'zoom out the page' in query :
                press_and_enter('Ctrl + -')
                
            elif 'switch tab' in query :
                tab = query.replace("switch tab ", "")
                Tab = tab.replace("to","")
                num = Tab
                bb = f'ctrl + {num}'
                press_and_release(bb)
            
            elif 'open' in query:
                name = query.replace("open ","")
                NameA = str(name)
                string = "https://www." + NameA + ".com"

                string_2 = string.replace(" ","")

                web.open(string_2)
            
            elif 'page up' in query :
                press_and_enter('Shift+Spacebar')
                
            elif 'go to top of the page' in query :
                press_and_enter('Home')  
                
            elif 'go to bottom of the page' in query :
                press_and_enter('End') 
                
            elif 'previous text' in query :
                press_and_enter('Alt + Down Arrow')      
                
            elif 'next tab' in query :
                press_and_enter('Ctrl+Tab')
                
            elif 'previous tab' in query :
                press_and_enter('Ctrl+Shift+Tab')
                
            elif 'restore last tab' in query :
                press_and_enter('Ctrl + Shift + T')
                
            elif 'close current window' in query :
                press_and_enter('Ctrl + Shift + W')
                
            elif 'source code' in query :
                press_and_enter('Ctrl+U')
                
            elif 'save the page' in query :
                press_and_enter('Ctrl+S')
                
            elif 'refresh the page' in query :
                press_and_enter('Ctrl+R')
        
        

        