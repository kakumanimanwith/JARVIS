import pyttsx3
import wikipedia
from pywikihow import WikiHow , search_wikihow
import os
import webbrowser as web
import speech_recognition as sr
import pywhatkit
import wolframalpha
import requests
from pyautogui import *
import pyperclip




engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voices',voices[0].id)
engine.setProperty('rate',120)


def speak(audio) :
    print("     ")
    print(f": {audio}")
    print("     ")
    engine.say(audio)
    engine.runAndWait()
    print("     ")
    
def GoogleSearch(term):
    query = term.replace("jarvis","")
    query = query.replace("what is","")
    query = query.replace("how to","")
    query = query.replace("what is","")
    query = query.replace(" ","")
    query = query.replace("what do you mean by","")

    writeab = str(query)

    oooooo = open('E:\jarvis asssistant\Text - Features\Data.txt','a')
    oooooo.write(writeab)
    oooooo.close()

    Query = str(term)

    pywhatkit.search(Query)

    
    if 'how to' in Query:

        max_result = 1

        how_to_func = search_wikihow(query=Query,max_results=max_result)

        assert len(how_to_func) == 1

        how_to_func[0].print()

        speak(how_to_func[0].summary)

    else:

        search = wikipedia.summary(Query,2)

        speak(f": According To Your Search : {search}")

def YouTubeSearch(term):
    result = "https://www.youtube.com/results?search_query=" + term
    web.open(result)
    speak("This Is What I Found For Your Search .")
    pywhatkit.playonyt(term)
    speak("This May Also Help You Sir .")

def Alarm(query):
    
    TimeHere=  open('E:\\jarvis asssistant\\Text - Features\\Data.txt','a')
    TimeHere.write(query)
    TimeHere.close()
    os.startfile("E:\\jarvis asssistant\\DataBase\\EtraPro\\Alarm.py")

def DownloadYouTube():
    from pytube import YouTube
    from pyautogui import click
    from pyautogui import hotkey
    import pyperclip
    from time import sleep

    sleep(2)
    click(x=942,y=59)
    hotkey('ctrl','c')
    value = pyperclip.paste()
    Link = str(value) # Important 

    def Download(link):


        url = YouTube(link)


        video = url.streams.first()


        video.download('E:\\jarvis asssistant\\DataBase\\youtube download\\')


    Download(Link)


    speak("Done Sir , I Have Downloaded The Video .")

    speak("You Can Go And Check It Out.")


    os.startfile('E:\\jarvis asssistant\\DataBase\\youtube download\\')

def SpeedTest() :
    os.startfile("E:\\jarvis asssistant\\DataBase\\Gui programs\\SpeedTestGui.py")
    
def WolfRam(query) :
    
    api_key = "Y8LQRP-J7K9A24HVH"
    
    requester = wolframalpha.Client(api_key)
    
    requested = requester.query(query)
    
    
    
    try :
        
        Answer = next(requested.results).text
        
        return Answer
    
    except :      
        speak("An string value is not answerable")
        
def Temp(query) :
    
    Term = str(query)
    
    Term = Term.replace("Jarvis","")
    Term = Term.replace("in ","")
    Term = Term.replace("what is the ","")
    Term = Term.replace("temperature ","")
    
    temp_query = str(Term)
    
    if 'outside' in temp_query :
        var1 = "Temperature Nellore"
        
        answer = WolfRam(var1)
        
        speak(f"{var1} Is {answer}")
        
    else :
        
        var2 = "Temperature in " + temp_query
        
        answ = WolfRam(var2)
        
        speak(f"{var2} is {answ}")
        
def tellDay():
      
    
    day = datetime.datetime.today().weekday() + 1
      
  
    Day_dict = {1: 'Monday', 2: 'Tuesday', 
                3: 'Wednesday', 4: 'Thursday', 
                5: 'Friday', 6: 'Saturday',
                7: 'Sunday'}
      
    if day in Day_dict.keys():
        day_of_the_week = Day_dict[day]
        print(day_of_the_week)
        speak("The day is " + day_of_the_week)

def startup() :
    speak('now me to introdue my self  \n i am jarvis \n a virtual artificial intelligence \n  and i am here to assist you with the relative tasks is best i can \n 24 hrs a day 7 days a week \n import your preferences todays system is fully operatable')
    
    
startup()







