import os 
from pyautogui import click
from keyboard import press
from keyboard import press_and_release
from keyboard import write
from time import sleep
import pyttsx3
import speech_recognition as sr
import webbrowser as web




engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voices',voices[0].id)
engine.setProperty('rate',170)


def speak(audio) :
    print("     ")
    print(f": {audio}")
    print("     ")
    engine.say(audio)
    engine.runAndWait()
    print("     ")

def TakeCommand():
    
    r = sr.Recognizer()

    with sr.Microphone() as source:

        print(": Listening....")

        r.pause_threshold = 1

        audio = r.listen(source)


    try:

        print(": Recognizing...")

        query = r.recognize_google(audio,language='en-in')

        print(f": Your Command : {query}\n")

    except:
        return ""

    return query.lower()

def WhatsappMsg(name,message) :
    

    
    
    click(x=22, y=1051)
    
    sleep(5)
    
    click(x=437, y=958)
    
    
    
    sleep(20)
    
    click(x=475, y=139)
    
    sleep(5)
    
    write(name)
    
    sleep(5)
    
    click(x=219, y=300)
    speak("the message will be sent within 15 seconds  ")
    sleep(5)
    
    click(x=806, y=995)
    
    sleep(0.5)
    
    write(message)
    
    click(x=1878, y=987)

def WhatsappCall(name) :
    
    speak("wait for a while to call the person it is processing ")
    
    click(x=22, y=1051)
    
    sleep(5)
    
    click(x=437, y=958)
    
    sleep(20)
    
    click(x=475, y=139)
    
    sleep(5)
    
    write(name)
    
    sleep(5)
    
    click(x=219, y=300)
    
    sleep(5)
    
    click(x=1712, y=53)

def WhatsappVideoCall(name) :
    
    
    
    click(x=22, y=1051)
    
    sleep(5)
    
    click(x=437, y=958)
    
    sleep(20)
    
    click(x=475, y=139)
    
    sleep(5)
    
    write(name)
    
    sleep(5)
    
    click(x=219, y=300)
    
    sleep(5)
    
    click(x=1652, y=55)
        
def WhatsappContactinfo(name) :
    
    click(x=22, y=1051)
    
    sleep(5)
    
    click(x=437, y=958)
    
    sleep(20)
    
    click(x=475, y=139)
    
    sleep(5)
    
    write(name)
    
    sleep(5)
    
    click(x=219, y=300)
    
    sleep(5)
    
    click(x=1865, y=53)
    
    sleep(5)
    
    click(x=1790, y=130)
    
    speak("pleae check information which is present on the screen ")

def WhatsappMutenotifications(name) :
    
    click(x=22, y=1051)
    
    sleep(5)
    
    click(x=437, y=958)
    
    sleep(15)
    
    click(x=475, y=139)
    
    sleep(0.5)
    
    write(name)
    
    sleep(1)
    
    click(x=219, y=300)
   
    sleep(0.5)
    
    click(x=1865, y=53)
    
    sleep(2)
    
    click(x=1736, y=224)
    
    sleep(2)
    
    click(x=1065, y=630)

    speak("the given contact has muted notifications for 8 hours .")

def WhatsappClearMsg(name) :
    
    
    click(x=22, y=1051)
    
    sleep(5)
    
    click(x=437, y=958)
    
    sleep(15)
    
    click(x=475, y=139)
    
    sleep(0.5)
    
    write(name)
    
    sleep(1)
    
    click(x=219, y=300)
   
    sleep(0.5)
    
    click(x=1865, y=53)
    
    sleep(2)
    
    click(x=1769, y=259)
    
    sleep(2)
    
    click(x=1088, y=576)
    
    speak("your chat has been cleared")

def ChromeAuto(command) :
    
    while True :
        
        query = str(command)
        
        if 'new tab' in query :
            
            press_and_release('ctrl + w')
            
        elif 'close tab' in query :
            
            press_and_release('ctrl + n')
            
        elif 'new window' in query :
            
            press_and_release('ctrl + h')
            
        elif 'downloads' in query :
            
            press_and_release('ctrl + j')
        
        elif 'bookmark' in query :
            
            press_and_release('ctrl + d')
            
            press('enter')
            
        elif 'incognito tab' in query :
            
            press_and_enter('ctrl + shift + n')
            
        elif 'homepage' in query :
            
            press_and_enter('alt + home')
            
        elif 'back page' in query:    
            press_and_enter('Alt + Left Arrow')
            
        elif 'forward a page' in query:
            press_and_enter('Alt + Right Arrow')
            
        elif 'full screen' in query :
            press_and_enter('F11')
            
        elif 'stop download' in query :
            press_and_enter('esc')
            
        elif 'zoom the page' in query :
            press_and_enter('Ctrl + +')
            
        elif 'zoom out the page' in query :
            press_and_enter('Ctrl + -')
            
        elif 'switch tab' in query :
            tab = query.replace("switch tab ", "")
            Tab = tab.replace("to","")
            num = Tab
            bb = f'ctrl + {num}'
            press_and_release(bb)
        
        elif 'open' in query:
            name = query.replace("open ","")
            NameA = str(name)
            string = "https://www." + NameA + ".com"

            string_2 = string.replace(" ","")

            web.open(string_2)
        
        elif 'page up' in query :
            press_and_enter('Shift+Spacebar')
            
        elif 'go to top of the page' in query :
            press_and_enter('Home')  
            
        elif 'go to bottom of the page' in query :
            press_and_enter('End') 
            
        elif 'previous text' in query :
            press_and_enter('Alt + Down Arrow')      
            
        elif 'next tab' in query :
            press_and_enter('Ctrl+Tab')
            
        elif 'previous tab' in query :
            press_and_enter('Ctrl+Shift+Tab')
            
        elif 'restore last tab' in query :
            press_and_enter('Ctrl + Shift + T')
            
        elif 'close current window' in query :
            press_and_enter('Ctrl + Shift + W')
            
        elif 'source code' in query :
            press_and_enter('Ctrl+U')
            
        elif 'save the page' in query :
            press_and_enter('Ctrl+S')
            
        elif 'refresh the page' in query :
            press_and_enter('Ctrl+R')
            
        
    
def YouTubeAuto(command):
    
    query = str(command)
    
        
        
    if 'pause' in query:
        sleep(2)
        press('space bar')
        
    elif 'resume' in query:
        sleep(2)
        press('space bar')
        
    elif 'full screen' in query:
        sleep(2)
        press('f')
        
    elif 'film screen' in query:
        sleep(2)
        press('t')
        
    elif 'skip' in query:
        sleep(2)
        press('l')
    
    elif 'back' in query:
        sleep(2)
        press('j')
        
    elif 'increase' in query:
        sleep(2)
        press_and_release('Up')
        
    elif 'decrease' in query:
        sleep(2)
        press_and_release('Down')
        
    elif 'previous' in query:
        sleep(2)
        press_and_release('SHIFT + p')
        
    elif 'next' in query:
        sleep(2)
        press_and_release('SHIFT + n')
        
    elif 'search' in query:
        sleep(2)
        click(x=791, y=114)

        speak("What To Search Sir ?")

        search = TakeCommand()

        write(search)

        sleep(0.8)

        press('enter')

    elif 'mute' in query:
        sleep(2)
        press('m')
        
    elif 'unmute' in query:
        sleep(2)
        press('m')
        
    elif 'my channel' in query:
        sleep(2)
        web.open("https://www.youtube.com/channel/UCWe6qs-LWENISXVMajlDJvQ")
        
    else:
        speak("No Command Found!")

YouTubeAuto('increase')          
            
            
            
            
            
            
             
            
            
            
            
            
            
        
                            
        
    
    

    
    
    
    
    
    