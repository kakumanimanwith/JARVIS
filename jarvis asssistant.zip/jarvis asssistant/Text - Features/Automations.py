import os 
from pyautogui import click
from keyboard import press
from keyboard import press_and_release

from keyboard import write
from time import sleep
import pyttsx3
import speech_recognition as sr
import webbrowser as web




engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voices',voices[0].id)
engine.setProperty('rate',170)



def speak(audio) :
    print("     ")
    print(f": {audio}")
    print("     ")
    engine.say(audio)
    engine.runAndWait()
    print("     ")

def TakeCommand():
    
    r = sr.Recognizer()

    with sr.Microphone() as source:

        print(": Listening....")

        r.pause_threshold = 1

        audio = r.listen(source)


    try:

        print(": Recognizing...")

        query = r.recognize_google(audio,language='en-in')

        print(f": Your Command : {query}\n")

    except:
        return ""

    return query.lower()

def WhatsappMsg(name,message) :
    

    
    
    click(x=1149, y=1042)
    
    sleep(5)
    
    click(x=437, y=958)
    
    
    
    sleep(20)
    
    click(x=475, y=139)
    
    sleep(5)
    
    write(name)
    
    sleep(5)
    
    click(x=219, y=300)
    speak("the message will be sent within 15 seconds  ")
    sleep(5)
    
    click(x=806, y=995)
    
    sleep(0.5)
    
    write(message)
    
    click(x=1878, y=987)

def WhatsappCall(name) :
    
    speak("wait for a while to call the person it is processing ")
    
    click(x=1149, y=1042)
    
    sleep(5)
    
    click(x=437, y=958)
    
    sleep(20)
    
    click(x=475, y=139)
    
    sleep(5)
    
    write(name)
    
    sleep(5)
    
    click(x=219, y=300)
    
    sleep(5)
    
    click(x=1712, y=53)

def WhatsappVideoCall(name) :
    
    
    
    click(x=1149, y=1042)
    
    sleep(5)
    
    click(x=437, y=958)
    
    sleep(20)
    
    click(x=475, y=139)
    
    sleep(5)
    
    write(name)
    
    sleep(5)
    
    click(x=219, y=300)
    
    sleep(5)
    
    click(x=1652, y=55)
        
def WhatsappContactinfo(name) :
    
    click(x=1149, y=1042)
    
    sleep(5)
    
    click(x=437, y=958)
    
    sleep(20)
    
    click(x=475, y=139)
    
    sleep(5)
    
    write(name)
    
    sleep(5)
    
    click(x=219, y=300)
    
    sleep(5)
    
    click(x=1865, y=53)
    
    sleep(5)
    
    click(x=1790, y=130)
    
    speak("pleae check information which is present on the screen ")

def WhatsappMutenotifications(name) :
    
    click(x=1149, y=1042)
    
    sleep(5)
    
    click(x=437, y=958)
    
    sleep(15)
    
    click(x=475, y=139)
    
    sleep(0.5)
    
    write(name)
    
    sleep(1)
    
    click(x=219, y=300)
   
    sleep(0.5)
    
    click(x=1865, y=53)
    
    sleep(2)
    
    click(x=1736, y=224)
    
    sleep(2)
    
    click(x=1065, y=630)

    speak("the given contact has muted notifications for 8 hours .")

def WhatsappClearMsg(name) :
    
    
    click(x=1149, y=1042)
    
    sleep(5)
    
    click(x=437, y=958)
    
    sleep(15)
    
    click(x=475, y=139)
    
    sleep(0.5)
    
    write(name)
    
    sleep(1)
    
    click(x=219, y=300)
   
    sleep(0.5)
    
    click(x=1865, y=53)
    
    sleep(2)
    
    click(x=1769, y=259)
    
    sleep(2)
    
    click(x=1088, y=576)
    
    speak("your chat has been cleared")

def ChromeAuto(command) :
    
    
        
    query = str(command)
    
    if 'new tab' in query :
        
        press_and_release('ctrl + t')
        
    elif 'close tab' in query :
        
        press_and_release('ctrl + w')
        
    elif 'new window' in query :
        
        press_and_release('ctrl + n')
        
    
    elif 'downloads' in query :
        
        press_and_release('ctrl + j')
    
    elif 'add bookmark' in query :
        
        press_and_release('ctrl + d')
        
        press('enter')
        
    elif 'incognito tab' in query :
        
        press_and_release('ctrl + shift + n')
        
    elif 'home page' in query :
        
        press_and_release('Alt + home')
        
    elif 'back page' in query:    
        press_and_release('Alt + Left Arrow')
        
    elif 'forward a page' in query:
        press_and_release('Alt + Right Arrow')
        
    elif 'full screen' in query :
        press_and_release('F11')
        
        
    elif 'zoom the page' in query :
        press_and_release('Ctrl + plus')
        
    elif 'zoom out the page' in query :
        press_and_release('Ctrl + -')
        
    elif 'switch tab' in query :
        tab = query.replace("switch tab ","")
        Tab = tab.replace("to","")
        num = Tab
        bb = f'ctrl + {num}'
        press_and_release(bb)
    
    elif 'open' in query:
        name = query.replace("open ","")
        NameA = str(name)
        string = "https://www." + NameA + ".com"

        string_2 = string.replace(" ","")

        web.open(string_2)
    
    elif 'page up' in query :
        press_and_release('Shift + Spacebar')
        
    elif 'go to top of the page' in query :
        press_and_release('Home')  
        
    elif 'go to bottom of the page' in query :
        press_and_release('End') 
        
    elif 'previous text' in query :
        press_and_release('Alt + Down Arrow')      
        
    elif 'next tab' in query :
        press_and_release('Ctrl+Tab')
        
    elif 'previous tab' in query :
        press_and_release('Ctrl+Shift+Tab')
        
    elif 'restore last tab' in query :
        press_and_release('Ctrl + Shift + T')
        
    elif 'close current window' in query :
        press_and_release('Ctrl + Shift + W')
        
    elif 'source code' in query :
        press_and_release('Ctrl+U')
        
    elif 'save the page' in query :
        press_and_release('Ctrl+S')
        
    elif 'refresh the page' in query :
        press_and_release('Ctrl+R')
        
    elif 'minimize window' in query :
        press_and_release('Windows + Down Arrow')
    
    elif 'quit google' in query :
        press_and_release('alt + f + x')
        
    elif 'maximize window' in query :
        press_and_release('Windows + Windows+Up Arrow')
        
    elif 'chrome menu' in query :
        press_and_release('Alt + e')
        
    elif 'show bookmark' in query :
        press_and_release('Ctrl + Shift + b')
        
    elif 'open bookmark manager' in query :
        press_and_release('Ctrl + Shift + o')
        
    elif 'history' in query :
        press_and_release('Ctrl + h')
        
    elif 'chrome task manager' in query :
        press_and_release('Shift + Esc')
        
    elif 'first item in the Chrome toolbar' in query :
        press_and_release('Shift + Alt + t')
        
    elif 'right most item in the Chrome toolbar' in query :
        press('F10')
        
    elif 'open developer tools' in query :
        press('F12')
        
        
    elif 'help centre' in query :
        press('F1')
        
    elif 'open feedback form' in query :
        press_and_release('Alt + Shift + i')
    
    elif 'open caret browsing' in query :
        press('F7')
            

def YouTubeAuto(command):
    

    
    query = str(command)

    if 'pause' in query:
        sleep(2)
        press('space bar')
        
    elif 'resume' in query:
        sleep(2)
        press('space bar')
        
    elif 'full screen' in query:
        sleep(2)
        press('f')
        
    elif 'film screen' in query:
        sleep(2)
        press('t')
        
    elif 'skip' in query:
        sleep(2)
        press('l')
    
    elif 'back' in query:
        sleep(2)
        press('j')
        
    elif 'increase' in query:
        sleep(2)
        press_and_release('Up')
        
    elif 'decrease' in query:
        sleep(2)
        press_and_release('Down')
        
    elif 'previous' in query:
        sleep(2)
        press_and_release('SHIFT + p')
        
    elif 'next' in query:
        sleep(2)
        press_and_release('SHIFT + n')
        
    elif 'search' in query:
        sleep(2)
        click(x=720, y=164)
        

        speak("What To Search Sir ?")

        search = TakeCommand()

        write(search)
        
        sleep(0.8)

        press('enter')

    elif 'mute' in query:
        sleep(2)
        press('m')
        
    elif 'unmute' in query:
        sleep(2)
        press('m')
        
    elif 'my channel' in query:
        sleep(2)
        web.open("https://www.youtube.com/channel/UCWe6qs-LWENISXVMajlDJvQ")
        
    else:
        speak("No Command Found!")

def WindiowsAuto(command):
    

    query = str(command)
    
    if 'home screen' in query:
        press_and_release('windows + m')
        
    elif 'minimize' in query:
        press_and_release('windows + m')

    elif 'show start' in query :
        press('windows')
    
    elif 'open setting' in query:
        press_and_release('windows + i')
        
    elif 'open search' in query:
        press_and_release('windows + s')
    
    elif 'screen shot' in query:
        press_and_release('windows + SHIFT + s')
        
    elif 'restore windows' in  query:
        press_and_release('Windows + Shift + M')
        
    else:
        speak("Sorry , No Command Found!")


 

            
           
            
            
            
            
             
            
            
            
            
            
            
        
                            
        
    
    

    
    
    
    
    
    