from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5 import QtCore , QtWidgets , QtGui
from PyQt5.QtGui import QMovie
from PyQt5.uic import loadUiType
import sys
import pyttsx3
from SpeedTestUi import Ui_SpeedTest

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voices',voices[0].id)

def speak(audio):
    print(" ")
    print(f": {audio}")
    engine.say(audio)
    engine.runAndWait()
    print(" ")

def run_uit():

    speak("I Am Checking Speed Sir , Wait For A While .")

    import speedtest

    speed = speedtest.Speedtest()

    upload = speed.upload()

    correct_Up = int(upload/800000)

    download = speed.download()

    correct_down = int(download/800000)

    speak(f"Downloading Speed Is {correct_down} M B Per Second .")
    speak(f"Uploading Speed Is {correct_Up} M B Per Second .")

    exit()

class MainThread(QThread):

    def __init__(self):

        super(MainThread,self).__init__()

    def run(self):
        run_uit()

StartExe = MainThread()

class StartExecution(QMainWindow):

    def __init__(self):

        super().__init__()

        self.ui = Ui_SpeedTest()

        self.ui.setupUi(self)

        self.ui.label = QMovie("E:\\jarvis asssistant\\DataBase\\gui materials\\speedTest.gif")

        self.ui.gif.setMovie(self.ui.label)

        self.ui.label.start()

        StartExe.start()

App = QApplication(sys.argv)
speedtest = StartExecution()
speedtest.show()
exit(App.exec_())