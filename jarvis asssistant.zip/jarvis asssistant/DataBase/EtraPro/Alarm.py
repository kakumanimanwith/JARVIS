import os
import datetime
import pyttsx3
import speech_recognition as sr

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voices',voices[0].id)
engine.setProperty('rate',170)


def speak(audio) :
    print("     ")
    print(f": {audio}")
    print("     ")
    engine.say(audio)             
    engine.runAndWait()
    print("     ")
    
extracted_time = open('E:\\jarvis asssistant\\Text - Features\\Data.txt','rt')
time = extracted_time.read()
Time = str(time)

delete_time = open("E:\\jarvis asssistant\\Text - Features\\Data.txt",'r+')
delete_time.truncate(0)
delete_time.close()

def RingerNow(time):
    
    time_to_set = str(time)
    time_now = time_to_set.replace("jarvis","")
    time_now = time_now.replace("set alarm for ","")
    time_now = time_now.replace("set ","")
    time_now = time_now.replace("alarm ","")
    time_now = time_now.replace("for ","")
    time_now = time_now.replace(" and ",":")

    Alarm_Time = str(time_now)

    while True:

        current_time = datetime.datetime.now().strftime("%H:%M")
        
        if current_time == Alarm_Time:
            print("Wake Up Sir , It's Time To Work .")
            speak("Wake Up Sir , It's Time To Work .")

        elif current_time>Alarm_Time:
            break

RingerNow(Time)


